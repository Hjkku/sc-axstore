const fs = require('fs');
const chalk = require('chalk');

global.owner = ['628']; //NOMOR OWNER
global.moderator = ['nomor']; //NOMOR ADMIM KALIAM ATAU KOSONGIN
global.author = 'AX DEVS'; //NAMA PEMBUAT
global.botname = 'AX STORE MARKET'; //NAMA BOT
global.packname = 'Bot WhatsApp';
global.listprefix = ['+','!','.'];
global.listv = ['•','●','■','✿','▲','➩','➢','➣','➤'];
global.tempatDB = 'database.json';
global.tempatStore = 'baileys_store.json';
global.pairing_code = true; //PILIH FALSE JIKA QRIS LOG
global.number_bot = ''; //NOMOR BOT

global.fake = {
	anonim: 'https://telegra.ph/file/95670d63378f7f4210f03.png',
	thumbnailUrl: 'https://pixhost.to/show/5655/693709127_ax.jpg',
	thumbnail: fs.readFileSync('./src/media/AX.png'),
	listfakedocs: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/pdf'],};

global.my = {
	ch: '', //LINK CHANNEL
	chId: '', //ID CHANMEL
	webstore: '', //WEBSITE BOT/KOSONGIN
	richmarket_key: '', //APIKEY WEB payinaja.my.id
  jasaotp_key: '', //APIKEY WEB JASAOTP
  permsCMD: [
  //menu
  'menu', 'grupmenu', 'botmenu', 'searchmenu', 'downmenu', 'store',
    //store memu
    'saldo', 'deposit', 'batal', 'listproduk', 'beli', 'nokoslist', 'nokoslayanan', 'nokosoperator', 'buynokos', 'cancelnokos',
    //bot menu
    'stiker', 's', 'totalfitur',  'brat', 'owner',
    //search menu
    'infohp', 'pint', 'pinterest', 'cekidff', 'cekidml',
    //down menu
    'tt', 'tiktok', 'ig', 'instagram', 'spotify', 'ytmp3'
  ] //LIST CMD YG DIIZINKAN AGAR USER BISA CMD
};

global.mygroupid = {
  gcOfc: [''], //ID GRUP AGAR BOT BISA TRANSAKSI
  gc: '', //LINK GRUP KALIAN
  gcaccid: '' //ID GRUP KALIAN UNTUK TERIMA/TOLAK PESANAN
};

global.mess = {
	admin: 'Fitur Khusus Admin!',
	botAdmin: 'B\u200cOT Bukan Admin!',
	group: 'Gunakan Di Group!'};

global.badWords = [
  'dongo', 'tolol', 'goblok', 'idiot', 'bego', 'geblek', 'picek', 'budeg',
  'ngentot', 'ngewe', 'entot', 'ewe', 'kontol', 'memek', 'jembut', 'peler', 
  'peju', 'coli', 'tetek', 'toket', 'perek', 'lonte', 'ajg', 'kntl', 
  'mmk', 'nonok', 'mokondo', 'ngaceng',
  'anjing', 'anjeng', 'anj', 'ajg', 'anyink', 'asuh', 'babi', 'monyet', 
  'kunyuk', 'asu', 'bajingan', 'bangsat', 'kampret',
  'jancok', 'jancuk', 'cuk', 'cok', 'ancok', 'itil', 'matamu', 
  'ndasmu', 'lontong', 'jablay', 'pantek', 'pukimak', 'kimak',
  'anjiirr', 'anjrit', 'anjrot', 'knthl', 'memeq', 'm3m3k', 'k0nt0l'];
global.chatLength = 500;
let file = require.resolve(__filename);
fs.watchFile(file, () => {
	fs.unwatchFile(file);
	console.log(chalk.redBright(`Update ${__filename}`));
	delete require.cache[file];
	require(file);
});