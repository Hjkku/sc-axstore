require('../settings');
const fs = require('fs'), toMs = require('ms'), path = require('path'), chalk = require('chalk');

class JsonDB {
    constructor(file = global.tempatDB) {
        this.file = file.includes(path.sep) ? file : path.join(process.cwd(), 'database', file);
        this.data = {};
        this.isWriting = false;
        this.writePending = false;
    }

    read = async () => {
        if (!fs.existsSync(this.file)) {
            fs.mkdirSync(path.dirname(this.file), { recursive: true });
            fs.writeFileSync(this.file, JSON.stringify(this.data, null, 2));
            return this.data;
        }
        try {
            return JSON.parse(fs.readFileSync(this.file));
        } catch {
            let backup = this.file + '.bak';
            let data = fs.existsSync(backup) ? JSON.parse(fs.readFileSync(backup)) : this.data;
            fs.writeFileSync(this.file, JSON.stringify(data, null, 2));
            return data;
        }
    }

    write = async (data) => {
        const content = data || global.db || {};
        if (this.isWriting) return (this.writePending = true);
        this.isWriting = true;
        try {
            let dir = path.dirname(this.file);
            if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
            if (fs.existsSync(this.file)) fs.copyFileSync(this.file, this.file + '.bak');
            if (Object.keys(content).length >= 0) {
                fs.writeFileSync(this.file, JSON.stringify(content, null, 2));
            }
        } catch (e) {
            console.error(chalk.red(`❌ Write Database Failed [${path.basename(this.file)}]:`), e);
        } finally {
            this.isWriting = false;
            if (this.writePending) { 
                this.writePending = false; 
                await this.write(content); 
            }
        }
    }
}

// Helper untuk inisialisasi di index.js
const dataBase = (source) => new JsonDB(source);

// Logika Hit & Command
const cmdAdd = (hit) => { hit.totalcmd = (hit.totalcmd || 0) + 1; hit.todaycmd = (hit.todaycmd || 0) + 1; };
const cmdDel = (hit) => hit.todaycmd = 0;
const cmdAddHit = (hit, feat) => { hit[feat] = (hit[feat] || 0) + 1; };

// --- LOGIKA PRODUK (NEW) ---
const addProduk = (id, nama, harga, stok, _dir) => {
    const obj = { 
        idProduk: id, 
        namaProduk: nama, 
        hargaProduk: harga, 
        stokProduk: stok 
    };
    _dir.push(obj);
};

const editProduk = (id, axstore, _dir) => {
    let pos = _dir.findIndex(a => a.idProduk === id);
    if (pos !== -1) {
        _dir[pos] = { ..._dir[pos], ...axstore };
    }
};

const delProduk = (id, _dir) => {
    let pos = _dir.findIndex(a => a.idProduk === id);
    if (pos !== -1) _dir.splice(pos, 1);
};

// Logika Expired Sewa/Premium
const addExpired = ({ id, expired, ...options }, _dir) => {
	const _cek = _dir.find((a) => a.id == id);
	if (_cek) {
		_cek.expired = _cek.expired + toMs(expired);
	} else {
		_dir.push({ id, expired: Date.now() + toMs(expired), ...options });
	}
};

const getPosition = (id, _dir) => _dir.findIndex(a => a.id === id || a.url === id);
const getExpired = (id, _dir) => _dir.find(a => a.id === id || a.url === id)?.expired;
const getStatus = (id, _dir) => _dir.find(a => a.id === id || a.url === id);
const checkStatus = (id, _dir) => _dir.some(a => a.id === id || a.url === id);
const getAllExpired = (_dir) => _dir.map(a => a.id);

const checkExpired = (_dir, conn) => {
	setInterval(() => {
		for (let i = _dir.length - 1; i >= 0; i--) {
			if (Date.now() >= _dir[i].expired) {
				if (conn) {
					conn.groupLeave(_dir[i].id).catch(e => {});
				}
				console.log(`Expired: ${_dir[i].id}`);
				_dir.splice(i, 1);
			}
		}
	}, 5 * 60 * 1000);
};

module.exports = { 
    dataBase, 
    cmdAdd, 
    cmdDel, 
    cmdAddHit, 
    addProduk,
    editProduk, 
    delProduk,
    addExpired, 
    getPosition, 
    getStatus, 
    getExpired, 
    checkStatus, 
    getAllExpired, 
    checkExpired 
};

// Auto Reload File
let file = require.resolve(__filename);
fs.watchFile(file, () => { 
    fs.unwatchFile(file); 
    console.log(chalk.redBright(`Update ${__filename}`)); 
    delete require.cache[file]; 
    require(file); 
});
