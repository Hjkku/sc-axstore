process.once('uncaughtException', console.error)
process.once('unhandledRejection', console.error)
require('./settings');
const fs = require('fs'), os = require('os'), util = require('util'), path = require('path'), axios = require('axios'), chalk = require('chalk'), cron = require('node-cron'), fetch = require('node-fetch'), webp = require('node-webpmux'), speed = require('performance-now'), moment = require('moment-timezone'), { performance } = require('perf_hooks'), { proto, generateWAMessageFromContent, generateWAMessageContent } = require('baileys'), { GroupUpdate, LoadDataBase } = require('./src/message'), { addExpired, checkExpired } = require('./src/database'), { runtime, sleep, isUrl, formatDate, formatp, generateProfilePicture, normalize, updateSettings, parseMention, fixBytes, similarity, pickRandom, tarBackup, createQRIS, checkStatus, cancelPayment, autoCekOTP } = require('./function');

const crypto = require('crypto');
cron.schedule('0 0 * * *', () => {
    Object.values(global.db.groups).forEach(g => g.limitlink = {});
    Object.values(global.db.users).forEach(u => u.limit = 20);
    console.log(chalk.green('✅ [SYSTEM] Database harian berhasil direset otomatis jam 00:00'));
}, { scheduled: true, timezone: "Asia/Jakarta" });

module.exports = axstore = async (axstore, m, msg, store) => {
    try {
        await LoadDataBase(axstore, m);
        const botNumber = axstore.decodeJid(axstore.user.id), sewa = db.sewa, set = db.set[botNumber] || {}, ownerNumber = set?.owner?.map(x => x.id) || owner;
        await GroupUpdate(axstore, m, store);

        const body = (m.type === 'conversation' ? m.message.conversation : m.type === 'imageMessage' ? m.message.imageMessage.caption : m.type === 'videoMessage' ? m.message.videoMessage.caption : m.type === 'extendedTextMessage' ? m.message.extendedTextMessage.text : m.type === 'reactionMessage' ? m.message.reactionMessage.text : m.type === 'buttonsResponseMessage' ? m.message.buttonsResponseMessage.selectedButtonId : m.type === 'listResponseMessage' ? m.message.listResponseMessage.singleSelectReply.selectedRowId : m.type === 'templateButtonReplyMessage' ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'interactiveResponseMessage' && m.quoted) ? (m.message.interactiveResponseMessage?.nativeFlowResponseMessage ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : '') : m.type === 'messageContextInfo' ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || '') : m.type === 'editedMessage' ? (m.message.editedMessage?.message?.protocolMessage?.editedMessage?.extendedTextMessage?.text || m.message.editedMessage?.message?.protocolMessage?.editedMessage?.conversation || '') : m.type === 'protocolMessage' ? (m.message.protocolMessage?.editedMessage?.extendedTextMessage?.text || m.message.protocolMessage?.editedMessage?.conversation || m.message.protocolMessage?.editedMessage?.imageMessage?.caption || m.message.protocolMessage?.editedMessage?.videoMessage?.caption || '') : '') || '';
        const budy = typeof m.text == 'string' ? m.text : '', isCreator = isOwner = [botNumber, ...ownerNumber, ...owner].map(v => v?.replace(/[^0-9]/g, '')).includes(m.sender.split('@')[0]);
        const cases = db.cases || (db.cases = [...fs.readFileSync('./axstore.js', 'utf-8').matchAll(/case\s+['"]([^'"]+)['"]/g)].map(x => x[1])), preReg = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@()#,'"*+÷/\%^&.©^]/gi;
        const prefix = isCreator ? (preReg.test(body) ? body.match(preReg)[0] : listprefix.find(a => body?.startsWith(a)) || '') : (set.multiprefix ? (preReg.test(body) ? body.match(preReg)[0] : listprefix.find(a => body?.startsWith(a)) || '¿') : listprefix.find(a => body?.startsWith(a)) || '¿');
        const isCmd = body.startsWith(prefix), args = body.trim().split(/ +/).slice(1), command = (isCreator || isCmd) ? body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() : '', text = q = args.join(' ');
        const quoted = m.quoted || m, mime = (quoted.msg || quoted).mimetype || '', qmsg = (quoted.msg || quoted), { author = 'AX DEVS', packname = 'Bot WhatsApp', botname = 'AX STORE' } = global;
        const jam = moment.tz('Asia/Jakarta').locale('id').format('HH:mm:ss'), ucapanWaktu = jam < '05:00' ? 'Selamat Pagi 🌉' : jam < '11:00' ? 'Selamat Pagi 🌄' : jam < '15:00' ? 'Selamat Siang 🏙' : jam < '18:00' ? 'Selamat Sore 🌅' : jam < '19:00' ? 'Selamat Sore 🌃' : 'Selamat Malam 🌌';
        const setv = pickRandom(listv), isNsfw = m.isGroup ? db.groups[m.chat].nsfw : false;

        if (m.isGroup) {
            const gdb = db.groups[m.chat], isBotAdmin = m.isBotAdmin, isAdmin = m.isAdmin, canAct = !isCreator && isBotAdmin && !isAdmin, del = () => axstore.sendMessage(m.chat, { delete: m.key });
            if (gdb.mute && !isCreator) return;
            if (!isCreator && !isAdmin && !gdb.membercmd) return;
            if (!m.key.fromMe && m.mentionedJid?.length === m.metadata.participants?.length && gdb.antihidetag && canAct) { await del(); return m.reply('*Anti Hidetag Sedang Aktif❗*') }
            if (!m.key.fromMe && gdb.antitagsw && canAct && (m.type === 'groupStatusMentionMessage' || m.message?.groupStatusMentionMessage || m.message?.protocolMessage?.type === 25 || (Object.keys(m.message || {}).length === 1 && Object.keys(m.message || {})[0] === 'messageContextInfo'))) {
                gdb.tagsw[m.sender] = (gdb.tagsw[m.sender] || 0) + 1;
                if (gdb.tagsw[m.sender] >= 5) { await axstore.groupParticipantsUpdate(m.chat, [m.sender], 'remove').catch(() => {}); m.reply(`@${m.sender.split("@")[0]} telah dikeluarkan dari grup\nKarena menandai grup dalam status WhatsApp sebanyak 5x`); delete gdb.tagsw[m.sender] }
            }
            if (!m.key.fromMe && gdb.antitoxic && canAct && badWords.some(w => budy.toLowerCase().includes(w))) await del();
            if (m.type === 'protocolMessage' && m.msg?.type === 0 && gdb.antidelete && canAct) {
                const chats = store?.messages?.[m.chat]?.array?.find(a => a.key.id === m.msg.key.id);
                if (chats?.message) {
                    const msgType = Object.keys(chats.message)[0], msgContent = chats.message[msgType];
                    msgContent.contextInfo = { mentionedJid: [chats.key.participant], isForwarded: true, forwardingScore: 1, quotedMessage: { conversation: '*Anti Delete❗*'}, ...chats.key };
                    await axstore.relayMessage(m.chat, { [msgType]: msgContent }, {});
                }
            }
            const isPromo = /chat\.whatsapp\.com\/|whatsapp\.com\/channel\//i.test(budy), isLink = /(https?:\/\/)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b/gi.test(budy);
            if (canAct && isPromo) {
                if (gdb.antiwapromo) await del();
                else if (gdb.antiwapromov2) {
                    gdb.limitlink = gdb.limitlink || {}; gdb.limitlink[m.sender] = (gdb.limitlink[m.sender] || 0) + 1;
                    if (gdb.limitlink[m.sender] > 2) { await del(); return m.reply(`⚠️ @${m.sender.split('@')[0]} Batas harian promosi link WhatsApp adalah *2x*!.`, { mentions: [m.sender] }) }
                }
            }
            if (canAct && isLink) {
                if (gdb.antilink) await del();
                else if (gdb.antilinkv2) {
                    await del(); gdb.warn = gdb.warn || {}; gdb.warn[m.sender] = (gdb.warn[m.sender] || 0) + 1;
                    if (gdb.warn[m.sender] >= 4) { await m.reply(`*「 KICKED 」*\n\nBatas peringatan terlampaui. Selamat tinggal @${m.sender.split('@')[0]}!`, { mentions: [m.sender] }); gdb.warn[m.sender] = 0; await axstore.groupParticipantsUpdate(m.chat, [m.sender], 'remove') }
                }
            }
            if (canAct && (gdb.antivirtex && (budy.length > 25000 || m.msg?.nativeFlowMessage?.messageParamsJson?.length > 2000))) {
                await del(); await axstore.relayMessage(m.chat, { extendedTextMessage: { text: `Terdeteksi @${m.sender.split('@')[0]} Mengirim Virtex/Bug..`, contextInfo: { mentionedJid: [m.sender], isForwarded: true, quotedMessage: { conversation: '*Anti Virtex❗*'}, ...m.key }}}, {}); await axstore.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
            }
            if (canAct && gdb.antibuglokasi && (m.type === 'locationMessage' || m.type === 'liveLocationMessage')) {
                const loc = m.message.locationMessage || m.message.liveLocationMessage;
                if (Math.abs(loc.degreesLatitude) > 90 || Math.abs(loc.degreesLongitude) > 180 || (loc.degreesLatitude === 0 && loc.degreesLongitude === 0)) {
                    await del(); await axstore.sendMessage(m.chat, { text: `Terdeteksi @${m.sender.split('@')[0]} mengirim Bug Lokasi❗`, mentions: [m.sender] }); await axstore.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
                }
            }
            if (m.message && m.key.remoteJid !== 'status@broadcast') console.log(chalk.black(chalk.bgWhite('[ PESAN ]:'), chalk.bgGreen(new Date().toLocaleString()), chalk.bgHex('#00EAD3')(budy || m.type), chalk.bgHex('#AF26EB')(m.key.id)));
        }

        let fileSha256 = (m.isMedia && m.msg.fileSha256 && db.cmd?.[m.msg.fileSha256.toString('base64')])?.text;
        checkExpired(sewa, axstore);
        if (!m.isGroup) return;
        if (!isCreator && !m.isAdmin && !my.permsCMD.includes(command)) return;

        switch(fileSha256 || command) {
          case 'cekipbot': { try {
        const res = await axios.get('https://api.ipify.org?format=json');
        m.reply(`IP Panel/VPS kamu adalah: *${res.data.ip}*`);} catch (e) {
        m.reply('Gagal mengecek IP');}} break
//PAYMENT GATEWAY / STORE MENU
//┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
      case 'bel': { m.react('✅');
      try {
        const groupMetadata = m.isGroup ? await axstore.groupMetadata(m.chat) : {}
        const groupName = m.isGroup ? groupMetadata.subject : 'Private Chat'
        const pureOwners = global.owner.map(v => v.split('@')[0] + '@s.whatsapp.net')
        const tagText = pureOwners.map(v => `@${v.split('@')[0]}`).join(' ')
        let groupLink = 'Bot bukan admin'
        if (m.isGroup) {
            try {
                const code = await axstore.groupInviteCode(m.chat)
                groupLink = 'https://chat.whatsapp.com/' + code} catch {
                groupLink = 'Gagal mengambil link (Bot bukan admin)'}}
        const teksNotif = `🔔 *NOTIFIKASI BEL* 🔔\n\n${tagText}\n\nAda yang ketuk bel nih!\n\n👤 *Nama:* @${m.sender.split('@')[0]}\n🏘️ *Asal Grup:* ${groupName}\n🔗 *Link Grup:* ${groupLink}`
        await axstore.sendMessage( mygroupid.gcaccid, {
            text: teksNotif,
            contextInfo: {
                mentionedJid: [...pureOwners, m.sender] }})} catch (e) {
        console.error(e)
        m.reply("Gagal mengetuk bel, terjadi kesalahan sistem.")}} break
		case 'deposit': {
			if (global.mygroupid.gcOfc.length > 0 && !global.mygroupid.gcOfc.includes(m.chat)) return;
    let user = global.db.users[m.sender]
    let bot = global.db.set[botNumber]
    let [command, ...args] = m.text.slice(1).split(' ')
    let q = args.join(' ')
    if (user.activeTrx) {
        return m.reply(`❌ *Gagal!* Kamu masih memiliki transaksi pending.\n\nSesi : "${user.activeTrx.replace('RICH', 'AX')}"\n\n• ketik *.bataldp* untuk membatalkan deposit.\n• ketik *.cancelnokos* jika Sesi "Menunggu"`)
    }
    if (!q) return m.reply('Masukkan nominal! Contoh: *.deposit 10000*')  
    let inputNominal = parseInt(q.replace(/[^0-9]/g, ''))  
    if (inputNominal < 1000) return m.reply('❌ *Gagal!* Minimal deposit adalah *Rp1.000*')
    let admin = 0  
    const rules = [
        { max: 10000, min: 100, maxA: 200 },
        { max: 20000, min: 200, maxA: 300 },
        { max: 50000, min: 400, maxA: 500 },
        { max: 150000, min: 800, maxA: 1000 },
        { max: 500000, min: 1800, maxA: 2000 },
        { max: 2000000, min: 3800, maxA: 4000 },
        { max: 9000000, min: 3800, maxA: 4000 }
    ]
    const rule = rules.find(r => inputNominal <= r.max)
    admin = Math.floor(Math.random() * (rule.maxA - rule.min + 1)) + rule.min
    let totalBayar = inputNominal + admin  
    await m.react('⏳')  
    let result = await createQRIS(totalBayar)  
    if (result && result.status === 'success') {  
        let { trx_id, qr_link, amount } = result.data  
        user.activeTrx = trx_id   
        let fNominal = new Intl.NumberFormat('id-ID').format(inputNominal)  
        let fAdmin = new Intl.NumberFormat('id-ID').format(admin)  
        let fTotal = new Intl.NumberFormat('id-ID').format(amount)  
        let caption = `*───────「 QRIS 」───────*\n\n📑 STATUS INFO\n┌  ◦ ID Trx : ${trx_id.replace('RICH', 'AX')}\n│  ◦ Type : Deposit\n└  ◦ Metode : QRIS All Payment\n\n💰 DETAIL PEMBAYARAN\n┌  ◦ Deposit : Rp${fNominal}\n│  ◦ Biaya Admin : Rp${fAdmin}\n└  ◦ Total Bayar : Rp${fTotal}\n\n🕒 AUTO CHECK\nBot mengecek otomatis setiap 30 detik. Ketik "${prefix}bataldp" untuk membatalkan.\nExpired 10 menit`
        let msg = await axstore.sendMessage(m.chat, { image: { url: qr_link }, caption: caption }, { quoted: m })
        user.lastMsgKey = msg.key
        await m.react('✅')
        let checkCount = 0  
        let autoCheck = setInterval(async () => {  
            checkCount++  
            if (user.activeTrx !== trx_id) return clearInterval(autoCheck)  
            let statusRes = await checkStatus(trx_id)  
            if (statusRes && statusRes.data.payment_status === 'SUCCESS') {
                clearInterval(autoCheck)  
                user.balance += inputNominal  
                user.activeTrx = ""  
                if (user.lastMsgKey) {
                    await axstore.sendMessage(m.chat, { delete: user.lastMsgKey })
                    user.lastMsgKey = null}
                let suksesTeks = `✅ *PEMBAYARAN BERHASIL!*\n\n✨ Deposit : Rp${fNominal}\n🆔 ID : ${trx_id.replace('RICH', 'AX')}\n\nSaldo telah ditambahkan.`
                await axstore.sendMessage(m.chat, { text: suksesTeks }, { quoted: m })
                return}
            if (checkCount >= 20) {
                user.activeTrx = ""
                clearInterval(autoCheck)
                if (user.lastMsgKey) {
                    await axstore.sendMessage(m.chat, { delete: user.lastMsgKey })
                    user.lastMsgKey = null}}}, 30000)
    } else {
        await m.react('❌')
        m.reply('❌ Sistem Error.')}} break
    case 'bataldp': {
      if (global.mygroupid.gcOfc.length > 0 && !global.mygroupid.gcOfc.includes(m.chat)) return;
    let user = global.db.users[m.sender]
    let bot = global.db.set[botNumber]
    if (!user.activeTrx || user.activeTrx === "Menunggu") return m.reply('❌ Kamu tidak memiliki transaksi deposit yang aktif.')
    await m.react('⏳')
    let oldId = user.activeTrx.replace('RICH', 'AX')
    if (user.lastMsgKey) {
        try {
            await axstore.sendMessage(m.chat, { delete: user.lastMsgKey })
            user.lastMsgKey = null
        } catch (e) {}
    }
    let result = await cancelPayment(user.activeTrx)
    user.activeTrx = ""
    await m.react('✅')
    m.reply(`Transaksi *${oldId}* telah dibatalkan.`)
} break
    case 'saldo': {
      if (global.mygroupid.gcOfc.length > 0 && !global.mygroupid.gcOfc.includes(m.chat)) return;
    let user = global.db.users[m.sender] 
    if (!user) {
        global.db.users[m.sender] = { balance: 0 }
        user = global.db.users[m.sender]}
    let formatSaldo = new Intl.NumberFormat('id-ID').format(user.balance || 0)
    let caption = `*───────「 USER BALANCE 」───────*

👤 *USER INFO*
┌  ◦ *Nama* : ${m.pushName || 'User'}
│  ◦ *Nomor* : @${m.sender.split('@')[0]}
└  ◦ *Status* : ${isCreator ? 'Owner' : 'Member'}

💰 *SALDO ANDA*
┌  ◦ *Total* : Rp${formatSaldo}
└  ◦ *Terdaftar* : ✅

Ingin tambah saldo?\nKetik *.deposit (nominal)*

━━━━━━━━━━━━━━━━━━
*© ${global.botname}*`
    await axstore.sendMessage(m.chat, { 
        text: caption, 
        mentions: [m.sender] 
    }, { quoted: m })} break
    case 'addsaldo': {
    if (!isCreator) return m.reply('❌ Fitur ini hanya untuk Owner!')
    let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.split('|')[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    let amount = q.split('|')[1]
    if (!target || !amount) return m.reply('Contoh: *.addsaldo @user|10000* atau reply chatnya')
    let user = global.db.users[target]
    if (!user) return m.reply('❌ User tidak ditemukan di database.')
    user.balance += parseInt(amount)
    m.reply(`✅ *BERHASIL TAMBAH SALDO*

👤 User: @${target.split('@')[0]}
💰 Nominal: +Rp${parseInt(amount).toLocaleString()}
Total Saldo: Rp${user.balance.toLocaleString()}`, { mentions: [target] })} break
    case 'hapussaldo': case 'delsaldo': {
    if (!isCreator) return
    let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.split('|')[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    let amount = q.split('|')[1]
    if (!target || !amount) return m.reply(`Contoh: *${prefix + command} @user|10000*`)
    let user = global.db.users[target]
    if (!user) return m.reply('❌ User tidak ditemukan di database.')
    if (parseInt(amount) > user.balance) return m.reply('❌ Nominal melebihi saldo user saat ini!')
    user.balance -= parseInt(amount)
    m.reply(`✅ *BERHASIL POTONG SALDO*

👤 User: @${target.split('@')[0]}
💰 Nominal: -Rp${parseInt(amount).toLocaleString()}
Total Saldo: Rp${user.balance.toLocaleString()}`, { mentions: [target] })} break 
    case 'ceksaldo': {
    if (!isCreator) return
    let target = m.mentionedJid[0] ? m.mentionedJid[0] : 
                 m.quoted ? m.quoted.sender : 
                 q ? (q.replace(/[^0-9]/g, '') + '@s.whatsapp.net') : 
                 null

    if (!target || target.length < 15) return m.reply('Contoh: *.ceksaldo @user* atau reply chatnya')
    
    let user = global.db.users[target]
    if (!user) return m.reply('❌ User tidak ditemukan di database. Pastikan target sudah pernah chat bot.')
    
    let caption = `*───「 CEK SALDO 」───*

👤 *User:* @${target.split('@')[0]}
💰 *Saldo:* Rp${(user.balance || 0).toLocaleString()}
📑 *Status:* ${user.activeTrx ? 'Ada Transaksi Pending' : 'Tidak Ada Transaksi'}

━━━━━━━━━━━━━━━━━━`
    
    m.reply(caption, { mentions: [target] })} break

    case 'listproduk': {
        if (global.mygroupid.gcOfc.length > 0 && !global.mygroupid.gcOfc.includes(m.chat)) return;
        if (!Array.isArray(global.db.produk)) global.db.produk = []
        if (global.db.produk.length === 0) return m.reply("Database produk kosong!")
        await axstore.sendButtonMsg(m.chat, {
            text: `Halo @${m.sender.split('@')[0]}\nSilahkan pilih produk yang ingin dibeli:`,
            footer: global.botname,
            mentions: [m.sender],
            buttons: [{
                buttonId: 'list_produk',
                buttonText: { displayText: '🛒 LIHAT PRODUK' },
                type: 2,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: 'Daftar Produk',
                        sections: [{
                            title: 'Produk Tersedia',
                            rows: global.db.produk.map(v => ({
                                title: v.namaProduk,
                                description: `ID: ${v.idProduk.toLocaleString()} | Harga: Rp${v.hargaProduk.toLocaleString()} | Stok: ${v.stokProduk}`,
                                id: `${prefix}beli ${v.idProduk}`
                            }))}]})}}]}, { quoted: m })} break
    case 'beli': {
    if (global.mygroupid.gcOfc.length > 0 && !global.mygroupid.gcOfc.includes(m.chat)) return;
    if (!Array.isArray(global.db.produk)) global.db.produk = []
    let [id, qty] = text.split('|')
    if (!id) return m.reply(`Contoh: ${prefix + command} panel atau ${prefix + command} panel|5`)
    let item = global.db.produk.find(v => v.idProduk === id)
    if (!item) return m.reply("❌ Produk tidak ditemukan!")
    if (item.stokProduk <= 0) return m.reply("❌ Maaf, stok produk ini sedang habis!")

    if (!qty) {
        let rows = []
        for (let i = 1; i <= 10; i++) {
            if (i <= item.stokProduk) {
                rows.push({
                    title: `Beli ${i} Pcs`,
                    description: `Estimasi: Rp${(item.hargaProduk * i).toLocaleString()}`,
                    id: `${prefix}beli ${id}|${i}`
                })
            }
        }
        
        let detailTeks = `🛒 *DETAIL PRODUK*\n\n`
        detailTeks += `📦 *Produk:* ${item.namaProduk}\n`
        detailTeks += `📝 *Deskripsi:* ${item.deskripsiProduk}\n`
        detailTeks += `💰 *Harga:* Rp${item.hargaProduk.toLocaleString()}\n`
        detailTeks += `📊 *Stok:* ${item.stokProduk}\n\n`
        detailTeks += `Silahkan pilih jumlah atau ketik manual:\n*${prefix}beli ${id}|jumlah*`

        return await axstore.sendButtonMsg(m.chat, {
            text: detailTeks,
            footer: global.botname,
            buttons: [{
                buttonId: 'qty_sel',
                buttonText: { displayText: '🔢 PILIH JUMLAH' },
                type: 2,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({ title: 'Jumlah Beli', sections: [{ title: 'Pilihan', rows }] })
                }
            }]
        }, { quoted: m })
    }

    let jumlah = Number(qty)
    if (isNaN(jumlah) || jumlah <= 0) return m.reply("❌ Jumlah harus berupa angka!")
    if (jumlah > item.stokProduk) return m.reply(`❌ Stok tidak cukup! Sisa: ${item.stokProduk}`)
    let totalHarga = item.hargaProduk * jumlah
    if (global.db.users[m.sender].balance < totalHarga) {
        return m.reply(`❌ Saldo kurang!\nTotal: Rp${totalHarga.toLocaleString()}\nSaldo: Rp${global.db.users[m.sender].balance.toLocaleString()}`)
    }
    
    let idAdmin = mygroupid.gcaccid
    let idOrder = 'TRX' + Math.floor(Math.random() * 100000)
    if (!global.db.pending_trx) global.db.pending_trx = {}
    global.db.pending_trx[idOrder] = { 
        buyer: m.sender, 
        chat: m.chat, 
        idProduk: id, 
        jumlah, 
        total: totalHarga,
        quotedId: m.key.id 
    }

    let notaAdmin = `📝 *PESANAN MASUK (PENDING)*\n\n` +
                    `🆔 *ID Order:* ${idOrder}\n` +
                    `👤 *Pembeli:* @${m.sender.split('@')[0]}\n` +
                    `📦 *Produk:* ${item.namaProduk}\n` +
                    `🔢 *Jumlah:* ${jumlah}\n` +
                    `💰 *Total Tagihan:* Rp${totalHarga.toLocaleString()}\n\n` +
                    `Silahkan klik tombol di bawah untuk konfirmasi.`

    await axstore.sendButtonMsg(idAdmin, {
        text: notaAdmin,
        footer: 'Admin Confirmation',
        mentions: [m.sender],
        buttons: [{
                buttonId: `${prefix}acc_order ${idOrder}`,
                buttonText: { displayText: '✅ KONFIRMASI' },
                type: 1 
            }, {
                buttonId: `${prefix}reject_order ${idOrder}`,
                buttonText: { displayText: '❌ TOLAK' },
                type: 1
            }]
    })
    m.reply(`⏳ *PENGAJUAN TERKIRIM*\n\nPesanan kamu sedang menunggu konfirmasi Owner. Mohon tunggu sebentar ya!`)
} break
    case 'addproduk': {
    if (!isCreator) return
    let [nama, id, harga, stok, deskripsi] = text.split('|')
    if (!nama || !id || !harga || !stok) return m.reply(`Format: ${prefix + command} Nama|ID|Harga|Stok|Deskripsi(Opsional)`)
    let cek = global.db.produk.find(v => v.idProduk === id)
    if (cek) return m.reply(`❌ ID "${id}" sudah dipakai di produk: *${cek.namaProduk}*`)
    
    global.db.produk.push({
        namaProduk: nama,
        idProduk: id,
        hargaProduk: Number(harga),
        stokProduk: Number(stok),
        deskripsiProduk: deskripsi || "Tidak ada deskripsi." // Default jika kosong
    })
    m.reply(`✅ *Berhasil Simpan*\n\n📦 Nama: ${nama}\n🆔 ID: ${id}\n💰 Harga: Rp${Number(harga).toLocaleString()}\n📊 Stok: ${stok}\n📝 Desk: ${deskripsi || '-'}`)
} break
    case 'setstok': {
    if (!isCreator) return
    let [id, jumlah] = text.split('|')
    if (!id || !jumlah) return m.reply(`*FORMAT SALAH*\n\nContoh Tambah: ${prefix + command} ml01|50\nContoh Kurang: ${prefix + command} ml01|-20`)
    if (!Array.isArray(global.db.produk)) global.db.produk = []
    let pos = global.db.produk.findIndex(v => v.idProduk === id)
    if (pos === -1) return m.reply(`❌ ID Produk "${id}" tidak ditemukan!`)
    let item = global.db.produk[pos]
    let nilaiInput = Number(jumlah)
    item.stokProduk = Number(item.stokProduk) + nilaiInput
    if (item.stokProduk < 0) item.stokProduk = 0
    m.react(nilaiInput > 0 ? '📈' : '📉')
    m.reply(`✨ *UPDATE STOK BERHASIL* ✨\n\n` +
            `📦 *Produk:* ${item.namaProduk}\n` +
            `🔢 *Perubahan:* ${nilaiInput > 0 ? '+' : ''}${nilaiInput}\n` +
            `📊 *Stok Sekarang:* ${item.stokProduk}`)} break
    case 'delproduk': {
    if (!isCreator) return
    if (!text) return m.reply(`Contoh: ${prefix + command} ml01`)
    if (!Array.isArray(global.db.produk)) global.db.produk = []
    let pos = global.db.produk.findIndex(v => v.idProduk === text)
    if (pos === -1) return m.reply(`ID Produk "${text}" tidak ditemukan!`)
    global.db.produk.splice(pos, 1)
    m.react('✅')
    m.reply(`Sukses menghapus produk dengan ID: ${text}`)} break
    case 'acc_order': {
    if (!isCreator && m.chat !== '120363424918873645@g.us') return 
    if (!text) return m.reply("ID Order tidak valid!")
    if (!global.db.pending_trx || !global.db.pending_trx[text]) return m.reply("❌ Transaksi kadaluarsa atau sudah diproses!")
    let data = global.db.pending_trx[text]
    let item = global.db.produk.find(v => v.idProduk === data.idProduk)
    let user = global.db.users[data.buyer]
    if (!user) return m.reply("❌ Data user tidak ditemukan!")
    if (user.balance < data.total) {
        delete global.db.pending_trx[text]
        return m.reply(`❌ GAGAL! Saldo @${data.buyer.split('@')[0]} tidak lagi mencukupi untuk transaksi ini. Pesanan dibatalkan otomatis.`)}
    if (!item || item.stokProduk < data.jumlah) {
        delete global.db.pending_trx[text]
        return m.reply(`❌ GAGAL! Stok produk sudah tidak mencukupi.`)
    }
    user.balance -= data.total
    item.stokProduk -= data.jumlah
    m.reply(`✅ Transaksi ${text} BERHASIL dikonfirmasi!`)
    let teksUser = `✨ *PESANAN DIKONFIRMASI* ✨\n\n` +
                   `Hai @${data.buyer.split('@')[0]}, pesananmu telah dikonfirmasi! ✅\n\n` +
                   `🛍️ *Produk:* ${item.namaProduk}\n` +
                   `🔢 *Jumlah:* ${data.jumlah}\n` +
                   `💰 *Total:* Rp${data.total.toLocaleString()}\n\n` +
                   `Saldo kamu telah terpotong. Terima kasih telah berbelanja!`
    await axstore.sendMessage(data.chat, { text: teksUser, mentions: [data.buyer] }, { quoted: { key: { id: data.quotedId, remoteJid: data.chat, fromMe: false }, message: { conversation: "Order Processed" } } })
    delete global.db.pending_trx[text]} break
    case 'reject_order': {
    if (!isCreator && m.chat !== '120363424918873645@g.us') return 
    if (!text) return m.reply("ID Order tidak valid!")
    if (!global.db.pending_trx || !global.db.pending_trx[text]) {
        return m.reply("❌ Data transaksi tidak ditemukan atau sudah diproses!")}

    let data = global.db.pending_trx[text]
    let item = global.db.produk.find(v => v.idProduk === data.idProduk)
    m.reply(`❌ Pesanan ${text} telah ditolak.`)
    let teksUser = `⚠️ *PESANAN DITOLAK* ⚠️\n\n` +
                   `Hai @${data.buyer.split('@')[0]}, mohon maaf pesananmu ditolak oleh Owner.\n\n` +
                   `🛍️ *Produk:* ${item ? item.namaProduk : 'Produk Tidak Diketahui'}\n` +
                   `🔢 *Jumlah:* ${data.jumlah}\n` +
                   `💰 *Status Saldo:* Refund\n\n` +
                   `Silahkan hubungi owner jika ada kendala.`
      await axstore.sendMessage(data.chat, { 
        text: teksUser, 
        mentions: [data.buyer] 
        }, { quoted: { key: { id: data.quotedId, remoteJid: data.chat, fromMe: false }, message: { conversation: "Order Rejected" } } })
        delete global.db.pending_trx[text]} break
    case 'cekantrean': {
      if (!isCreator) return 
      if (!global.db.pending_trx || Object.keys(global.db.pending_trx).length === 0) {
        return m.reply("📭 Tidak ada antrean transaksi saat ini.")}
    let teks = `📝 *DAFTAR ANTREAN TRANSAKSI*\n\n`
    let i = 1
    for (let id in global.db.pending_trx) {
        let trx = global.db.pending_trx[id]
        teks += `${i++}. 🆔 *${id}*\n`
        teks += `   👤 User: @${trx.buyer.split('@')[0]}\n`
        teks += `   📦 Produk: ${trx.idProduk}\n`
        teks += `   💰 Total: Rp${trx.total.toLocaleString()}\n`
        teks += `   📅 ID: ${id}\n\n`}
    teks += `Gunakan *${prefix}acc_order ID* atau *${prefix}reject_order ID* untuk memproses.`
    m.reply(teks, m.chat, { mentions: Object.values(global.db.pending_trx).map(v => v.buyer) })} break
    case 'clearantrean': {
    if (!isCreator) return 
    if (!global.db.pending_trx || Object.keys(global.db.pending_trx).length === 0) {
        return m.reply("Antrean sudah kosong.")}
    global.db.pending_trx = {}
    m.reply("✅ Seluruh antrean transaksi telah dibersihkan (Database dikosongkan).")} break

    case 'nokoslist': {
      if (global.mygroupid.gcOfc.length > 0 && !global.mygroupid.gcOfc.includes(m.chat)) return;
          try {
              const response = await axios.get('https://api.jasaotp.id/v1/negara.php', {
                  params: { apikey: my.jasaotp_key }})
              const res = response.data
              if (res.success && res.data.length > 0) {
                  let sortedData = res.data.sort((a, b) => a.nama_negara.localeCompare(b.nama_negara))

                  let rows = sortedData.map(v => ({
                      header: '',
                      title: v.nama_negara.toUpperCase(),
                      description: `Klik untuk lihat layanan (ID: ${v.id_negara})`,
                      id: `${prefix}nokoslayanan ${v.id_negara}|${v.nama_negara}`}))
                  await axstore.sendButtonMsg(m.chat, {
                      text: `🌍 *DAFTAR NEGARA (A-Z)*\n\nSilahkan pilih negara untuk melihat daftar layanan yang tersedia.`,
                      footer: global.botname,
                      buttons: [{
                          buttonId: 'list_negara',
                          buttonText: { displayText: '🏳️ PILIH NEGARA' },
                          type: 2,
                          nativeFlowInfo: {
                              name: 'single_select',
                              paramsJson: JSON.stringify({
                                  title: 'Daftar Negara',
                                  sections: [{ title: 'Negara Tersedia', rows: rows }]})}}]}, { quoted: m })} else {
                  m.reply(`❌ GAGAL: ${res.message || 'Data tidak ditemukan'}`)}
          } catch (e) {
              m.reply("⚠️ Error mengambil daftar negara.")}} break
    case 'nokoslayanan': {
          if (!text) return m.reply(`Contoh: ${prefix + command} 6|indonesia`)
          let [idNegara, namaNegara] = text.split('|')
          try {
              const response = await axios.get(`https://api.jasaotp.id/v1/layanan.php`, {
                  params: { api_key: my.jasaotp_key, negara: idNegara }})
              const res = response.data[idNegara]
              if (res) {
                  let rows = Object.keys(res).map(key => ({
                      header: '',
                      title: res[key].layanan.toUpperCase(),
                      description: `Harga: Rp${res[key].harga.toLocaleString()} | Stok: ${res[key].stok}`,
                      id: `${prefix}nokosoperator ${idNegara}|${namaNegara}|${key}|${res[key].layanan}|${res[key].harga}`}))
                  await axstore.sendButtonMsg(m.chat, {
                      text: `📱 *PILIH LAYANAN*\n\nNegara: ${namaNegara.toUpperCase()}\n\nSilahkan pilih aplikasi:`,
                      footer: global.botname,
                      buttons: [{
                          buttonId: 'list_layanan',
                          buttonText: { displayText: '📲 PILIH APLIKASI' },
                          type: 2,
                          nativeFlowInfo: {
                              name: 'single_select',
                              paramsJson: JSON.stringify({
                                  title: 'Daftar Layanan',
                                  sections: [{ title: `Layanan di ${namaNegara}`, rows: rows }]})}}]}, { quoted: m })}
          } catch (e) { m.reply("⚠️ Gagal mengambil daftar layanan.") }} break
    case 'nokosoperator': {
          let [idNegara, namaNegara, kodeLayanan, namaLayanan, harga] = text.split('|')

          try {
              const response = await axios.get(`https://api.jasaotp.id/v1/operator.php`, {
                  params: { api_key: my.jasaotp_key, negara: idNegara }})
              const listOp = response.data.data[idNegara]
              if (listOp) {
                  let rows = listOp.map(op => ({
                      header: '',
                      title: op.toUpperCase(),
                      description: `Gunakan operator ${op} untuk ${namaLayanan}`,
                      id: `${prefix}buynokos ${idNegara}|${kodeLayanan}|${op}|${harga}`}))
                  await axstore.sendButtonMsg(m.chat, {
                      text: `📶 *PILIH OPERATOR*\n\nNegara: ${namaNegara.toUpperCase()}\nLayanan: ${namaLayanan.toUpperCase()}\nHarga: Rp${Number(harga).toLocaleString()}\n\nTerakhir, pilih operator untuk memproses pembelian:`,
                      footer: global.botname,
                      buttons: [{
                          buttonId: 'list_op',
                          buttonText: { displayText: '📡 PILIH OPERATOR' },
                          type: 2,
                          nativeFlowInfo: {
                              name: 'single_select',
                              paramsJson: JSON.stringify({
                                  title: 'Daftar Operator',
                                  sections: [{ title: `Operator Tersedia`, rows: rows }]})}}]}, { quoted: m })}} catch (e) { m.reply("⚠️ Gagal mengambil daftar operator.") }} break
    case 'buynokos': {
    if (global.mygroupid.gcOfc.length > 0 && !global.mygroupid.gcOfc.includes(m.chat)) return;
    let user = global.db.users[m.sender]
    let bot = global.db.set[botNumber]
    if (user.activeTrx) {
        return m.reply(`❌ *Gagal!* Kamu masih memiliki transaksi pending.\n\nSesi : "${user.activeTrx.replace('RICH', 'AX')}"\n\n• ketik *.cancelnokos* untuk membatalkan beli nokos.\n• ketik *.bataldp* jika Sesi berupa ID QRIS`)}
    let [idNegara, kodeLayanan, operator, harga] = text.split('|')
    if (!idNegara || !kodeLayanan || !operator) {
        return m.reply("⚠️ Data order tidak lengkap. Silahkan pilih ulang dari daftar negara.")}
    let totalHarga = Number(harga)
    if (user.balance < totalHarga) {
        return m.reply(`❌ Saldo Anda tidak cukup!\nHarga: Rp${totalHarga.toLocaleString()}\nSaldo: Rp${user.balance.toLocaleString()}`)}
    await m.react('⏳')
    try {
        const response = await axios.get(`https://api.jasaotp.id/v1/order.php`, {
            params: {
                api_key: my.jasaotp_key,
                negara: idNegara,
                layanan: kodeLayanan,
                operator: operator}})
        const res = response.data
        if (res.success) {
            user.activeTrx = "Menunggu"
            bot.tertundaTrx += 1
            user.balance -= totalHarga
            let orderId = res.data.order_id
            let nomor = res.data.number
            let teks = `✅ *ORDER BERHASIL*\n\n🆔 *ID Order:* ${orderId}\n📱 *Nomor:* ${nomor}\n📡 *Operator:* ${operator.toUpperCase()}\n💰 *Harga:* Rp${totalHarga.toLocaleString()}\n\n⏳ *Status:* Menunggu OTP secara otomatis...`
            await axstore.sendButtonMsg(m.chat, {
                text: teks,
                footer: global.botname,
                buttons: [{ 
                    buttonId: `${prefix}cancelnokos ${orderId}|${totalHarga}`, 
                    buttonText: { displayText: '❌ BATALKAN' }, 
                    type: 1 }]
            }, { quoted: m })
            autoCekOTP(axstore, m, orderId)
        } else {
            m.reply(`❌ *Gagal Order:* ${res.message}`)}
    } catch (e) {
        console.error(e)
        m.reply("⚠️ Terjadi kesalahan koneksi.")}} break
    case 'cancelnokos': {
    if (global.mygroupid.gcOfc.length > 0 && !global.mygroupid.gcOfc.includes(m.chat)) return;
    let user = global.db.users[m.sender]
    let bot = global.db.set[botNumber]
    let [orderId, hargaRefund] = text.split('|')
    if (!orderId) return m.reply(`⚠️ Gunakan tombol batal atau ketik ".cancelnokos ${orderId}"`)
    if (user.activeTrx !== "Menunggu") return m.reply(`❌ Kamu tidak memiliki sesi nokos yang aktif!`)
    await m.react('⏳')
    try {
        const response = await axios.get(`https://api.jasaotp.id/v1/cancel.php`, {
            params: {
                api_key: my.jasaotp_key,
                id: orderId}})
        const res = response.data
        if (res.success) {
            if (global.nokosSession && global.nokosSession[orderId]) {
                delete global.nokosSession[orderId]}
            user.activeTrx = ""
            bot.gagalTrx += 1
            bot.tertundaTrx -= 1
            let nominal = Number(hargaRefund) || 0
            user.balance += nominal
            let teks = `✅ *PESANAN DIBATALKAN*\n\n🆔 *ID Order:* ${orderId}\n💰 *Refund:* Rp${nominal.toLocaleString()}\n\nSaldo telah dikembalikan secara otomatis.`
            m.reply(teks)} else {
            m.reply(`❌ *Gagal :* ${res.message}`)}} catch (e) {
        m.reply("⚠️ Gagal menghubungi server.")}} break
      
//┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
//GROUP MENU
//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
      case 'acakp': {
        if (!m.isGroup) return m.reply(mess.group);
        if (!text) return m.reply(`Contoh: ${prefix + command} 1`);
        let participants = m.metadata.participants;
        let member = participants.map(u => u.id);
        let jumlah = parseInt(text);
        if (isNaN(jumlah) || jumlah <= 0) return m.reply('Masukkan jumlah yang valid!');
        if (jumlah > member.length) return m.reply('Jumlah pemenang melebihi jumlah member!');
        let pemenangAsli = [];
        let tempMember = [...member];
        for (let i = 0; i < jumlah; i++) {
          let index = Math.floor(Math.random() * tempMember.length);
          pemenangAsli.push(tempMember.splice(index, 1)[0])}
          let { key } = await axstore.sendMessage(m.chat, { text: '📢 *GIVEAWAY DIMULAI!*' });
          await sleep(1000);
          let countdown = ['5...', '4...', '3...', '2...', '1...'];
          for (let i = 0; i < countdown.length; i++) {
            let namaAcak = member[Math.floor(Math.random() * member.length)];
            await axstore.sendMessage(m.chat, { 
            text: `🎲 *MENGACAK PEMENANG...*\n\n⏳ *${countdown[i]}*\n[ @${namaAcak.split('@')[0]} ]`, 
            edit: key, 
            mentions: [namaAcak] })
        await sleep(1500)}
    await axstore.sendMessage(m.chat, { text: '✨ *DAN PEMENANGNYA ADALAH...*', edit: key })
    await sleep(2000)
    let teksPemenang = `🎊 *CONGRATULATIONS!* 🎊\n\nSelamat kepada:\n`
    pemenangAsli.forEach((v, i) => {
        teksPemenang += `\n> @${v.split('@')[0]}`})
    teksPemenang += `\n\n kamu memenangkan giveaway kali ini! 🎉\nSilahkan hubungi penyedia event.`
    await axstore.sendMessage(m.chat, { 
        text: teksPemenang, 
        edit: key, 
        mentions: pemenangAsli })} break
			case 'kick': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				if (text || m.quoted) {
					const numbersOnly = text ? text.replace(/\D/g, '') + '@s.whatsapp.net' : m.quoted?.sender
					const findJid = axstore.findJidByLid(numbersOnly.replace(/[^0-9]/g, '') + '@lid', store);
					const klss = numbersOnly.replace(/[^0-9]/g, '') + (findJid ? '@lid' :  '@s.whatsapp.net')
					const nmrnya = axstore.findJidByLid(klss, store, true)
					await axstore.groupParticipantsUpdate(m.chat, [nmrnya], 'remove').catch((err) => m.reply('Gagal!'))
				} else m.reply(`Contoh: ${prefix + command} 62xxx`)
			} break
			case 'promote': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				if (text || m.quoted) {
					const numbersOnly = text ? text.replace(/\D/g, '') + '@s.whatsapp.net' : m.quoted?.sender
					const findJid = axstore.findJidByLid(numbersOnly.replace(/[^0-9]/g, '') + '@lid', store);
					const klss = numbersOnly.replace(/[^0-9]/g, '') + (findJid ? '@lid' :  '@s.whatsapp.net')
					const nmrnya = axstore.findJidByLid(klss, store, true)
					await axstore.groupParticipantsUpdate(m.chat, [nmrnya], 'promote').catch((err) => m.reply('Gagal!'))
				} else m.reply(`Contoh: ${prefix + command} 62xxx`)
			} break
			case 'demote': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				if (text || m.quoted) {
					const numbersOnly = text ? text.replace(/\D/g, '') + '@s.whatsapp.net' : m.quoted?.sender
					const findJid = axstore.findJidByLid(numbersOnly.replace(/[^0-9]/g, '') + '@lid', store);
					const klss = numbersOnly.replace(/[^0-9]/g, '') + (findJid ? '@lid' :  '@s.whatsapp.net')
					const nmrnya = axstore.findJidByLid(klss, store, true)
					await axstore.groupParticipantsUpdate(m.chat, [nmrnya], 'demote').catch((err) => m.reply('Gagal!'))
				} else m.reply(`Contoh: ${prefix + command} 62xxx`)
			} break
			case 'warn': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				if (text || m.quoted) {
					const numbersOnly = text ? text.replace(/\D/g, '') + '@s.whatsapp.net' : m.quoted?.sender
					const findJid = axstore.findJidByLid(numbersOnly.replace(/[^0-9]/g, '') + '@lid', store);
					const klss = numbersOnly.replace(/[^0-9]/g, '') + (findJid ? '@lid' :  '@s.whatsapp.net')
					const nmrnya = axstore.findJidByLid(klss, store, true)
					if (!db.groups[m.chat].warn[nmrnya]) {
						db.groups[m.chat].warn[nmrnya] = 1
						m.reply('Peringatan 1/4, akan dikick sewaktu waktu❗')
					} else if (db.groups[m.chat].warn[nmrnya] >= 3) {
						await axstore.groupParticipantsUpdate(m.chat, [nmrnya], 'remove').catch((err) => m.reply('Gagal!'))
						delete db.groups[m.chat].warn[nmrnya]
					} else {
						db.groups[m.chat].warn[nmrnya] += 1
						m.reply(`Peringatan ${db.groups[m.chat].warn[nmrnya]}/4, akan dikick sewaktu waktu❗`)}
				} else m.reply(`Contoh: ${prefix + command} @tag/628xx`)
			} break
			case 'unwarn': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				if (text || m.quoted) {
					const numbersOnly = text ? text.replace(/\D/g, '') + '@s.whatsapp.net' : m.quoted?.sender
					const findJid = axstore.findJidByLid(numbersOnly.replace(/[^0-9]/g, '') + '@lid', store);
					const klss = numbersOnly.replace(/[^0-9]/g, '') + (findJid ? '@lid' :  '@s.whatsapp.net')
					const nmrnya = axstore.findJidByLid(klss, store, true)
					if (db.groups[m.chat]?.warn?.[nmrnya]) {
						delete db.groups[m.chat].warn[nmrnya]
						m.reply('Berhasil Menghapus Warning!')
					}
				} else m.reply(`Contoh: ${prefix + command} 62xxx`)
			} break
			case 'setname': case 'setsubject': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				if (text || m.quoted) {
					const teksnya = text ? text : m.quoted.text
					await axstore.groupUpdateSubject(m.chat, teksnya).catch((err) => m.reply('Gagal!'))
				} else m.reply(`Contoh: ${prefix + command} textnya`)
			} break
			case 'setdesc': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				if (text || m.quoted) {
					const teksnya = text ? text : m.quoted.text
					await axstore.groupUpdateDescription(m.chat, teksnya).catch((err) => m.reply('Gagal!'))
				} else m.reply(`Contoh: ${prefix + command} textnya`)
			} break
	 	  case 'setppgc': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				if (!m.quoted) return m.reply('Reply Gambar yang mau dipasang di Profile Bot')
				if (!/image/.test(quoted.type)) return m.reply(`Reply Image Dengan Caption ${prefix + command}`)
				let media = await quoted.download();
				let { img } = await generateProfilePicture(media, text.length > 0 ? null : 512)
				await axstore.query({
					tag: 'iq',
					attrs: {
						target: m.chat,
						to: '@s.whatsapp.net',
						type: 'set',
						xmlns: 'w:profile:picture'
					},
					content: [{ tag: 'picture', attrs: { type: 'image' }, content: img }]
				});
				m.reply('Sukses')
			} break
			case 'delete': case 'del': {
				if (!m.quoted) return m.reply('Reply pesan yang mau di delete')
				await axstore.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: m.isBotAdmin ? false : true, id: m.quoted.id, participant: m.quoted.sender }})
			} break
			case 'urlgrup': case 'urlgc': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				let response = await axstore.groupInviteCode(m.chat)
				await m.reply(`https://chat.whatsapp.com/${response}\n\nLink Group : ${(store.groupMetadata[m.chat] ? store.groupMetadata[m.chat] : (store.groupMetadata[m.chat] = await axstore.groupMetadata(m.chat))).subject}`, { detectLink: true })
			} break
			case 'revoke': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				await axstore.groupRevokeInvite(m.chat).then((a) => {
					m.reply(`Sukses Menyetel Ulang, Tautan Undangan Grup ${m.metadata.subject}`)
				}).catch((err) => m.reply('Gagal!'))
			}	break
	    case 'grup': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				console.log(`${m.isBotAdmin}`)
				let set = db.groups[m.chat]
				switch (args[0]?.toLowerCase()) {
					case 'close': case 'open':
					await axstore.groupSettingUpdate(m.chat, args[0] == 'close' ? 'announcement' : 'not_announcement').then(a => m.reply(`*Sukses ${args[0] == 'open' ? 'Membuka' : 'Menutup'} Group*`))
					break
					case 'join':
					const _list = await axstore.groupRequestParticipantsList(m.chat).then(a => a.map(b => b.jid))
					if (/(a(p|pp|cc)|(ept|rove))|true|ok/i.test(args[1]) && _list.length > 0) {
						await axstore.groupRequestParticipantsUpdate(m.chat, _list, 'approve').catch(e => m.react('❌'))
					} else if (/reject|false|no/i.test(args[1]) && _list.length > 0) {
						await axstore.groupRequestParticipantsUpdate(m.chat, _list, 'reject').catch(e => m.react('❌'))
					} else m.reply(`List Request Join :\n${_list.length > 0 ? '- @' + _list.join('\n- @').split('@')[0] : '*Nothing*'}\nExample : ${prefix + command} join acc/reject`)
					break
					case 'pesansementara': case 'disappearing':
					if (/90|7|1|24|on/i.test(args[1])) {
						axstore.sendMessage(m.chat, { disappearingMessagesInChat: /90/i.test(args[1]) ? 7776000 : /7/i.test(args[1]) ? 604800 : 86400 })
					} else if (/0|off|false/i.test(args[1])) {
						axstore.sendMessage(m.chat, { disappearingMessagesInChat: 0 })
					} else m.reply('Silahkan Pilih :\n90 hari, 7 hari, 1 hari, off')
					break
					case 'membercmd': case 'antilink': case 'antilinkv2': case 'antiwapromo': case 'antiwapromov2': case 'antibuglokasi': case 'antivirtex': case 'antidelete': case 'welcome': case 'antitoxic': case 'nsfw': case 'antihidetag': case 'setinfo': case 'antitagsw': case 'leave': case 'promote': case 'demote':
    if (/on|true/i.test(args[1])) {
        if (set[args[0]]) return m.reply(`*${args[0]} Sudah Aktif Sebelumnya*`)
        if (args[0] === 'antilink') {
          if (set['antilinkv2']) {             set['antilinkv2'] = false}
            } else if (args[0] === 'antilinkv2') {
              if (set['antilink']) {
                set['antilink'] = false}}
                set[args[0]] = true
                m.reply(`*Sukses Change ${args[0]} To On*`)
                } else if (/off|false/i.test(args[1])) {
                  if (!set[args[0]]) return m.reply(`*${args[0]} Sudah Nonaktif Sebelumnya*`)
                  set[args[0]] = false
                  m.reply(`*Sukses Change ${args[0]} To Off*`)
                  } else {
                    m.reply(`❗${args[0].charAt(0).toUpperCase() + args[0].slice(1)} on/off`)}
          break
					case 'setwelcome': case 'setleave': case 'setpromote': case 'setdemote':
					if (args[1]) {
						set.text[args[0]] = args.slice(1).join(' ');
						m.reply(`Sukses Mengubah ${args[0].split('set')[1]} Menjadi:\n${set.text[args[0]]}`)
					} else m.reply(`Example:\n${prefix + command} ${args[0]} Isi Pesannya\n\nMisal Dengan tag:\n${prefix + command} ${args[0]} Kepada @\nMaka akan Menjadi:\nKepada @0\n\nMisal dengan Tag admin:\n${prefix + command} ${args[0]} Dari @admin untuk @\nMaka akan Menjadi:\nDari @${m.sender.split('@')[0]} untuk @0\n\nMisal dengan Nama grup:\n${prefix + command} ${args[0]} Dari @admin untuk @ di @subject\nMaka akan Menjadi:\nDari @${m.sender.split('@')[0]} untuk @0 di ${m.metadata.subject}`)
					break
					default:
					m.reply(`Settings Group ${m.metadata.subject}\n- open\n- close\n- join acc/reject\n- disappearing 90/7/1/off\n- membercmd on/off ${set.membercmd ? '🟢' : '🔴'}\n- antilink on/off ${set.antilink ? '🟢' : '🔴'}\n- antilinkv2 on/off ${set.antilinkv2 ? '🟢' : '🔴'}\n- antiwapromo on/off ${set.antiwapromo ?  '🟢' : '🔴'}\n- antiwapromov2 on/off ${set.antiwapromov2 ?  '🟢' : '🔴'}\n- antibuglokasi on/off ${set.antibuglokasi ?  '🟢' : '🔴'}\n- antivirtex on/off ${set.antivirtex ? '🟢' : '🔴'}\n- antidelete on/off ${set.antidelete ? '🟢' : '🔴'}\n- welcome on/off ${set.welcome ? '🟢' : '🔴'}\n- leave on/off ${set.leave ? '🟢' : '🔴'}\n- promote on/off ${set.promote ? '🟢' : '🔴'}\n- demote on/off ${set.demote ? '🟢' : '🔴'}\n- setinfo on/off ${set.setinfo ? '🟢' : '🔴'}\n- nsfw on/off ${set.nsfw ? '🟢' : '🔴'}\n- antihidetag on/off ${set.antihidetag ? '🟢' : '🔴'}\n- antitagsw on/off ${set.antitagsw ? '🟢' : '🔴'}\n\n- setwelcome _textnya_\n- setleave _textnya_\n- setpromote _textnya_\n- setdemote _textnya_\n\nExample:\n${prefix + command} antilink off`)
				}
			}	break
			case 'tagall': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				let setv = pickRandom(listv)
				let teks = `*Tag All*\n\n*Pesan :* ${q ? q : ''}\n\n`
				for (let mem of m.metadata.participants) {
					teks += `${setv} @${mem.id.split('@')[0]}\n`
				}
				await m.reply(teks, { mentions: m.metadata.participants.map(a => a.id) })
			}	break
			case 'hidetag': case 'ht': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				await m.reply(q ? q : '', { mentions: m.metadata.participants.map(a => a.id) })
			} break
			case 'totag': {
				if (!m.isBotAdmin) return m.reply(mess.botAdmin)
				if (!m.quoted) return m.reply(`Reply pesan dengan caption ${prefix + command}`)
				delete m.quoted.chat
				await axstore.sendMessage(m.chat, { forward: m.quoted.fakeObj(), mentions: m.metadata.participants.map(a => a.id) })
			}	break
			case 'listonline': case 'liston': {
				if (!m.isGroup) return m.reply(mess.group)
				let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
				if (!store.presences || !store.presences[id]) return m.reply('Sedang Tidak ada yang online!')
				let online = [...Object.keys(store.presences[id]), botNumber]
				await m.reply('List Online:\n\n' + online.map(v => setv + ' @' + v.replace(/@.+/, '')).join`\n`, { mentions: online }).catch((e) => m.reply('Sedang Tidak Ada Yang Online..'))
			}	break
//┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
//BOT MENU
//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
			case 'owner': {
    let infoTeks = `*SOCIAL MEDIA*

🔗 *Website:* ${my.webstore || 'axstore.my.id'}

🔗 *Link Channel:* ${my.ch || 'https://whatsapp.com/channel/0029Vb7Kqkn9sBI2KKptwH2S'}

👥 *Link Grup:* ${mygroupid.gc || 'https://chat.whatsapp.com/EkgXLLf5T2H1qUlewCH8Dq'}

👤️ *Owner:*
${global.owner}
🛡️ *Moderator:*
${global.moderator}

_Silahkan hubungi jika ada kendala atau ingin order!_`
    await axstore.sendMessage(m.chat, {
        text: infoTeks,
        contextInfo: {
            externalAdReply: {
                title: `CUSTOMER SERVICE ${global.botname}`,
                body: 'Klik di sini untuk info lebih lanjut',
                thumbnail: fake.thumbnail,
                thumbnailUrl: mygroupid.gc,
                sourceUrl: mygroupid.gc,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m })
} break
			case 'totalfitur': {
				const total = ((fs.readFileSync('./axstore.js').toString()).match(/case '/g) || []).length
				m.reply(`Total Fitur : ${total}`);
			}	break
			case 'runtime': case 'bot': {
				switch(args[0]) {
					case 'mode': case 'public': case 'self':
					if (!isCreator) return 
					if (args[1] == 'public' || args[1] == 'all') {
						if (axstore.public && set.grouponly && set.privateonly) return m.reply('*Sudah Aktif Sebelumnya*')
						axstore.public = set.public = true
						set.grouponly = true
						set.privateonly = true
						m.reply('*Sukses Change To Public Usage*')
					} else if (args[1] == 'self') {
						set.grouponly = false
						set.privateonly = false
						axstore.public = set.public = false
						m.reply('*Sukses Change To Self Usage*')
					} else if (args[1] == 'group') {
						set.grouponly = true
						set.privateonly = false
						m.reply('*Sukses Change To Group Only*')
					} else if (args[1] == 'private') {
						set.grouponly = false
						set.privateonly = true
						m.reply('*Sukses Change To Private Only*')
					} else m.reply('Mode self/public/group/private/all')
					break
				 case 'autobio': case 'autoread': case 'readsw': case 'multiprefix':
					if (!isCreator) return 
					if (args[1] == 'on') {
						if (set[args[0]]) return m.reply('*Sudah Aktif Sebelumnya*')
						set[args[0]] = true
						m.reply('*Sukses Change To On*')
					} else if (args[1] == 'off') {
						set[args[0]] = false
						m.reply('*Sukses Change To Off*')
					} else m.reply(`${args[0].charAt(0).toUpperCase() + args[0].slice(1)} on/off`)
					break
					case 'set':
					let settingsBot = Object.entries(set).map(([key, value]) => {
						let list = key == 'status' ? new Date(value).toLocaleString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : (typeof value === 'boolean') ? (value ? 'on🟢' : 'off🔴') : value;
						return `- ${key.charAt(0).toUpperCase() + key.slice(1)} : ${list}`;
					}).join('\n');
					m.reply(`Settings Bot @${botNumber.split('@')[0]}\n${settingsBot}\n\nExample: ${prefix + command} mode`);
					break
					default:
					if (args[0] || args[1]) m.reply(`*Please Sellect Settings :*\n- Mode : *${prefix + command} mode self/public*\n- Auto Bio : *${prefix + command} autobio on/off*\n- Auto Read : *${prefix + command} autoread on/off*\n- Read Sw : *${prefix + command} readsw on/off*\n- Multi Prefix : *${prefix + command} multiprefix on/off*`)
				}
				if (!args[0] && !args[1]) return m.reply(`*B\u200cot Telah Online Selama*\n*${runtime(process.uptime())}*`)
			}	break
			case 'ping': {
				const used = process.memoryUsage()
				const cpus = os.cpus().map(cpu => {
					cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
					return cpu
				})
				const cpu = cpus.reduce((last, cpu, _, { length }) => {
					last.total += cpu.total
					last.speed += cpu.speed / length
					last.times.user += cpu.times.user
					last.times.nice += cpu.times.nice
					last.times.sys += cpu.times.sys
					last.times.idle += cpu.times.idle
					last.times.irq += cpu.times.irq
					return last
				}, {
					speed: 0,
					total: 0,
					times: {
						user: 0,
						nice: 0,
						sys: 0,
						idle: 0,
						irq: 0
					}
				})
				let timestamp = speed()
				let latensi = speed() - timestamp
				neww = performance.now()
				oldd = performance.now()
				respon = `Kecepatan Respon ${latensi.toFixed(4)} _Second_ \n ${oldd - neww} _miliseconds_\n\nRuntime : ${runtime(process.uptime())}\n\n💻 Info Server\nRAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}\n\n_NodeJS Memory Usaage_\n${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}\n\n${cpus[0] ? `_Total CPU Usage_\n${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}\n_CPU Core(s) Usage (${cpus.length} Core CPU)_\n${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}`.trim()
				m.reply(respon)
			}	break
			case 'rvo': {
				if (!m.quoted) return m.reply(`Reply view once message\nExample: ${prefix + command}`)
				try {
					if (m.quoted.msg.viewOnce) {
						delete m.quoted.chat
						m.quoted.msg.viewOnce = false
						await m.reply({ forward: m.quoted })
					} else m.reply(`Reply view once message\nExample: ${prefix + command}`)
				} catch (e) {
					m.reply('Media Tidak Valid!')
				}
			}	break
			case 'inspect': {
				if (!text) return m.reply('Masukkan Link Grup atau Saluran!')
				let _grup = /chat.whatsapp.com\/([\w\d]*)/;
				let _saluran = /whatsapp\.com\/channel\/([\w\d]*)/;
				if (_grup.test(text)) {
					await axstore.groupGetInviteInfo(text.match(_grup)[1]).then((_g) => {
						let teks = `*[ INFORMATION GROUP ]*\n\nName Group: ${_g.subject}\nGroup ID: ${_g.id}\nCreate At: ${new Date(_g.creation * 1000).toLocaleString()}${_g.owner ? ('\nCreate By: ' + _g.owner) : '' }\nLinked Parent: ${_g.linkedParent}\nRestrict: ${_g.restrict}\nAnnounce: ${_g.announce}\nIs Community: ${_g.isCommunity}\nCommunity Announce:${_g.isCommunityAnnounce}\nJoin Approval: ${_g.joinApprovalMode}\nMember Add Mode: ${_g.memberAddMode}\nDescription ID: ${'`' + _g.descId + '`'}\nDescription: ${_g.desc}\nParticipants:\n`
						_g.participants.forEach((a) => {
							teks += a.admin ? `- Admin: @${a.id.split('@')[0]} [${a.admin}]\n` : ''
						})
						m.reply(teks)
					}).catch((e) => {
						if ([400, 406].includes(e.data)) return m.reply('Grup Tidak Di Temukan❗');
						if (e.data == 401) return m.reply('B\u200cot Di Kick Dari Grup Tersebut❗');
						if (e.data == 410) return m.reply('Url Grup Telah Di Setel Ulang❗');
					});
				} else if (_saluran.test(text) || text.endsWith('@newsletter') || !isNaN(text)) {
					await axstore.newsletterMsg(text.match(_saluran)[1]).then((n) => {
						m.reply(`*[ INFORMATION CHANNEL ]*\n\nID: ${n.id}\nState: ${n.state.type}\nName: ${n.thread_metadata.name.text}\nCreate At: ${new Date(n.thread_metadata.creation_time * 1000).toLocaleString()}\nSubscriber: ${n.thread_metadata.subscribers_count}\nVerification: ${n.thread_metadata.verification}\nDescription: ${n.thread_metadata.description.text}\n`)
					}).catch((e) => m.reply('Saluran Tidak Di Temukan❗'))
				} else m.reply('Hanya Support Url Grup atau Saluran!')
			}	break
			case 'sticker': case 'stiker': case 's': {
				if (!/image|video|sticker/.test(quoted.type)) return m.reply(`Kirim/reply gambar/video/gif dengan caption ${prefix + command}\nDurasi Image/Video/Gif 1-9 Detik`)
				let media = await quoted.download()
				let teks1 = text.split`|`[1] ? text.split`|`[0] : `Dibuat oleh : AX STORE BOT\nOwner : AX DEVS\nWa : ${global.owner}\nGrup : ${mygroupid.gc}`
				let teks2 = text.split`|`[0] ? text.split`|`[1] : `join yaaa`

				if (/image|webp/.test(mime)) {
					m.react('⏳')
					await axstore.sendAsSticker(m.chat, media, m, { packname: teks1, author: teks2 })
				} else if (/video/.test(mime)) {
					if ((qmsg).seconds > 11) return m.reply('Maksimal 10 detik!')
					m.react('⏳')
					await axstore.sendAsSticker(m.chat, media, m, { packname: teks1, author: teks2 })
				} else m.reply(`Kirim/reply gambar/video/gif dengan caption ${prefix + command}\nDurasi Video/Gif 1-9 Detik`)
			} break
      case 'brat': {
    let teks = text ? text : m.quoted && m.quoted.text ? m.quoted.text : null
    if (!teks) return m.reply(`Kirim/reply pesan *${prefix + command}* Teksnya`)
    try {
        let res = `https://api.nexray.web.id/maker/brat?text=${encodeURIComponent(teks)}`
        await axstore.sendAsSticker(m.chat, res, m)
        m.react('✅')
    } catch (e) {
        console.error(e)
        m.reply('❌ Gagal membuat sticker Brat. Server mungkin sedang offline!')}} break
//┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
//SEARCH MENU
//┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
    case 'infohp': {
			  if (!text) return m.reply('invalid?\nContoh: .infohp Infinix Note 50x')
			  try {
			    m.react('🔍')
			    const res = await axios.get(`https://api.nexray.web.id/search/gsmarena?q=${encodeURIComponent(text)}`)
			    if (!res.data.status || !res.data.result || res.data.result.length === 0) {
            return m.reply('Spesifikasi HP tidak ditemukan. Coba ketik nama HP dengan benar.')}
            const data = res.data.result[0]
            let teks = `*─── [ SMARTPHONE INFO ] ───*\n\n`
        teks += `📱 *Model:* ${data.name}\n`
        teks += `🆔 *ID:* ${data.id}\n\n`
        teks += `📝 *Spesifikasi:* \n${data.description}\n\n`
        teks += `_Source: GSMArena_`
        if (data.thumbnail) {
            await axstore.sendMessage(m.chat, { 
                image: { url: data.thumbnail }, 
                caption: teks 
            }, { quoted: m })
            } else {
            m.reply(teks)}
            } catch (e) {
              console.log(e)
              m.reply('Gagal mengambil data dari GSMArena.')}} break
    case 'pinterest': case 'pint': {
    if (!text) return m.reply(`Example: ${prefix + command} hu tao`)
    try {
        m.react('🔍')
        const response = await fetch(`https://api.nexray.web.id/search/pinterest?q=${encodeURIComponent(text)}`)
        const anu = await response.json()
        if (!anu.status || !anu.result || anu.result.length === 0) return m.reply('Gambar tidak ditemukan!')
        const results = anu.result.slice(0, 5) 
        let cards = []
        for (let i of results) {
            let imageUrl = i.images_url 
            if (!imageUrl) continue 
            const imageMsg = await generateWAMessageContent({ 
                image: { url: imageUrl } 
            }, { 
                upload: axstore.waUploadToServer 
            })
            cards.push({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: `👤 *Pinner:* ${i.pinner?.full_name || '-'}\n📌 *Title:* ${i.grid_title || 'Pinterest Image'}`
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: "Geser untuk gambar lainnya"
                }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: "Pinterest Search",
                    hasMediaAttachment: true,
                    ...imageMsg
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: "cta_url",
                            buttonParamsJson: JSON.stringify({
                                display_text: "👁️ Buka di Browser",
                                url: i.pin})}]})})}
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `Berikut hasil pencarian Pinterest untuk: *${text}*`
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: cards})})}}
        }, { quoted: m })
        await axstore.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
        } catch (e) {
          console.error(e)
          m.reply('Gagal memproses Pinterest Carousel. Pastikan koneksi stabil.')}} break
    case 'cekidff': {
        if (!text) return m.reply('Masukkan UID Free Fire!\nContoh: .cekidff 2049889224')
        try {
          m.reply('🔍 Memuat data dari database Garena...')
          const res = await axios.get(`https://api.nexray.web.id/stalker/freefire?uid=${text}`)
          if (!res.data.status) return m.reply('ID tidak ditemukan atau server sedang sibuk.')
          const data = res.data.result
          let caption = `*─── [ FF ACCOUNT STALKER ] ───*\n\n`
        caption += `👤 *Nickname:* ${data.name}\n`
        caption += `🆔 *ID:* ${data.uid}\n`
        caption += `🌍 *Region:* ${data.region}\n`
        caption += `🆙 *Level:* ${data.level} (Exp: ${data.exp.toLocaleString()})\n`
        caption += `❤️ *Likes:* ${data.likes.toLocaleString()}\n`
        caption += `🏆 *BR Rank Point:* ${data.br_rank_point}\n`
        caption += `🎮 *CS Rank Point:* ${data.cs_rank_point}\n`
        caption += `💯 *Credit Score:* ${data.credit_score}\n`
        caption += `📅 *Dibuat:* ${data.created_at}\n`
        caption += `🕒 *Login Terakhir:* ${data.last_login}\n`
        caption += `📝 *Bio:* ${data.signature || '-'}\n\n`
        
        caption += `*─── [ GUILD INFO ] ───*\n`
        caption += `🏰 *Nama:* ${data.guild_name}\n`
        caption += `🛡️ *Level Guild:* ${data.guild_level}\n`
        caption += `👥 *Anggota:* ${data.guild_member}/${data.guild_capacity}\n\n`
        
        caption += `_Source: ${data.source}_`
        try {
          const bannerUrl = `https://api.nexray.web.id${data.banner_image}`
          await axstore.sendMessage(m.chat, { 
                image: { url: bannerUrl }, 
                caption: caption 
            }, { quoted: m })
        } catch (imgError) {
            m.reply(caption)}
            } catch (e) {
              console.log(e)
              m.reply('Server cek id ff sedang offline.')}} break
    case 'cekidml': {
        if (!text) return m.reply('Masukkan ID dan Zone ML!\nContoh: .cekidml 1373911405|15655')
        let [id, zone] = text.split('|')
        if (!id || !zone) return m.reply('Format salah! Gunakan: ID|Zone\nContoh: .cekidml 1373911405|15655')
        try {
          m.reply('🔍 Mencari data User MLBB...')
          const res = await axios.get(`https://api.nexray.web.id/stalker/v1/mlbb?id=${id}&zone=${zone}`)
          if (!res.data.status) return m.reply('Data tidak ditemukan. Pastikan ID dan Zone benar.')
          const data = res.data.result
          let teks = `*─── [ MLBB ACCOUNT STALKER ] ───*\n\n`
        teks += `👤 *Username:* ${data.username}\n`
        teks += `🆔 *ID:* ${data.id}\n`
        teks += `🌀 *Zone:* ${data.zone}\n`
        teks += `🌍 *Region:* ${data.region}\n\n`
        
        teks += `*─── [ RECHARGE STATUS ] ───*\n`
        let recharge = data.first_recharge.filter(v => v.available === true)
        if (recharge.length > 0) {
            teks += `💎 *First Recharge Tersedia:*\n`
            recharge.forEach(v => {
                teks += `• Promo ${v.title} ✅\n`
            })
        } else {
            teks += `💎 Promo First Recharge sudah diambil semua.\n`
        }
        teks += `\n_Timestamp: ${res.data.timestamp}_`
        m.reply(teks)
        } catch (e) {
          console.log(e)
          m.reply('Server cek id ml sedang offline.')}} break
//┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
//DOWMLOAD MENU
//┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
    case 'tt': case 'tiktok': {
			  if (!text) return m.reply(`Example: ${prefix + command} https://vt.tiktok.com/ZSxxxx`)
			  if (!text.includes('tiktok.com')) return m.reply('Url Tidak Valid!')
			  try {
			    m.react('⏳')
          const response = await fetch(`https://api.nexray.web.id/downloader/tiktok?url=${encodeURIComponent(text)}`)
          const hasil = await response.json()
          if (!hasil.status) return m.reply('Gagal mengambil data dari server!')
          const res = hasil.result
        if (res.data) {
            await axstore.sendMessage(m.chat, { 
                video: { url: res.data }
            }, { quoted: m })
        } else {
            return m.reply('Video tidak ditemukan!')}
        } catch (e) {
          console.log(e)
          m.react('❌')
          }} break
    case 'ig': case 'instagram': {
    if (!args[0]) return m.reply(`Salah, Contoh: ${prefix + command} https://www.instagram.com/p/Cxxx/`)
    try {
        const res = await (await fetch(`https://api.nexray.web.id/downloader/v2/instagram?url=${args[0]}`)).json()
        if (!res?.status || !res?.result?.media?.length) return m.reply("Gagal mengambil media!")
        
        const { media, title } = res.result
        const caption = title && title !== '-' ? `*Title:* ${title}` : `*Instagram Downloader*`
        
        if (media.length > 1) {
            const cards = media.map((item, i) => {
                const url = typeof item === 'string' ? item : item.url // Handle jika item itu objek
                return {
                    url: url,
                    body: `Media Ke-${i + 1}`,
                    footer: `Slide Instagram`,
                    buttons: [{
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({ display_text: "Source Media", url: url })
                    }]
                }
            })
            await axstore.sendCarouselMsg(m.chat, caption, "Instagram Slides", cards, { quoted: m })
        } else {
            let singleUrl = media[0]
            if (typeof singleUrl !== 'string' && singleUrl.url) singleUrl = singleUrl.url
            
            const isVideo = String(singleUrl).includes('.mp4') || String(singleUrl).includes('video')
            
            await axstore.sendMessage(m.chat, { 
                [isVideo ? 'video' : 'image']: { url: singleUrl }, 
                caption 
            }, { quoted: m })
        }
    } catch (e) {
        console.error(e)
        m.reply("Terjadi kesalahan sistem atau link tidak valid.")
    }
} break
    case 'spotify': {
    if (!args[0]) return m.reply(`Salah, Contoh: ${prefix + command} https://open.spotify.com/track/xxx`)
    m.react('⏳')
    try {
        const res = await (await fetch(`https://api.nexray.web.id/downloader/spotify?url=${args[0]}`)).json()
        if (!res?.status || !res?.result?.url) return m.reply("Gagal mengambil lagu!")

        const { url, thumbnail } = res.result

        await axstore.sendMessage(m.chat, {
            audio: { url: url },
            mimetype: 'audio/mpeg',
            ptt: false,
            contextInfo: {
                externalAdReply: {
                    title: "Spotify Downloader", 
                    thumbnailUrl: thumbnail,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m })
        m.react('✅')
    } catch (e) {
        console.error(e)
        m.reply("Error!")}} break
    case 'ytmp3': {
    if (!args[0]) return m.reply(`Salah, Contoh: ${prefix + command} https://youtu.be/xxx`)
    m.react('⏳')
    try {
        const res = await (await fetch(`https://api.nexray.web.id/downloader/v1/ytmp3?url=${args[0]}`)).json()

        if (!res.status || !res.result.url) return m.reply("Gagal mengonversi video ke MP3.")
        const { title, author, url, thumbnail } = res.result
        await axstore.sendMessage(m.chat, {
            audio: { url: url },
            mimetype: 'audio/mpeg',
            ptt: false,
            contextInfo: {
                externalAdReply: {
                    title: title,
                    body: `Channel: ${author}`,
                    thumbnailUrl: thumbnail,
                    sourceUrl: args[0],
                    mediaType: 2,
                    renderLargerThumbnail: false
                }
            }
        }, { quoted: m })
    } catch (e) {
        console.error(e)
        m.reply("Server sedang sibuk, coba lagi nanti.")}} break
//┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
// OWNER MENU
//┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
		case 'listgc': {
				if (!isCreator) return 
				let anu = Object.keys(store.messages).filter(a => a.endsWith('@g.us'));
				let teks = `● *LIST GROUP CHAT*\n\nTotal Group : ${anu.length} Group\n\n`
				if (anu.length === 0) return m.reply(teks)
				for (let i of anu) {
					let metadata;
					try {
						metadata = store.groupMetadata[i]
					} catch (e) {
						metadata = (store.groupMetadata[i] = await axstore.groupMetadata(i).catch(e => ({})))
					}
					teks += metadata?.subject ? `${setv} *Nama :* ${metadata.subject}\n${setv} *Admin :* ${metadata.owner ? `@${metadata.owner.split('@')[0]}` : '-' }\n${setv} *ID :* ${metadata.id}\n${setv} *Dibuat :* ${moment(metadata.creation * 1000).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}\n${setv} *Member :* ${metadata.participants.length}\n\n=====================\n\n` : ''
				}
				await m.reply(teks)
			} break
		case 'creategc': case 'buatgc': {
				if (!isCreator) return 
				if (!text) return m.reply(`Example:\n${prefix + command} *Nama Gc*`)
				let group = await axstore.groupCreate(q, [m.sender])
				let res = await axstore.groupInviteCode(group.id)
				await m.reply(`*Link Group :* *https://chat.whatsapp.com/${res}*\n\n*Nama Group :* *${group.subject}*\nSegera Masuk dalam 30 detik\nAgar menjadi Admin`, { detectLink: true })
				await sleep(30000)
				await axstore.groupParticipantsUpdate(group.id, [m.sender], 'promote').catch(e => {});
				await axstore.sendMessage(group.id, { text: 'Done' })
			} break
		case 'addsewa': {
				if (!isCreator) return 
				if (!text) return m.reply(`Example:\n${prefix + command} https://chat.whatsapp.com/xxx | waktu\n${prefix + command} https://chat.whatsapp.com/xxx | 30 hari`)
				let [teks1, teks2] = text.split('|')?.map(x => x.trim()) || [];
				if (!isUrl(teks1) && !teks1.includes('chat.whatsapp.com/')) return m.reply('Link Invalid!')
				const urlny = teks1.match(/chat\.whatsapp\.com\/([0-9A-Za-z]+)/)
				if (!urlny) return m.reply('Link Invalid❗')
				try {
					await axstore.groupAcceptInvite(urlny[1])
				} catch (e) {
					if (e.data == 400) return m.reply('Grup Tidak Di Temukan❗');
					if (e.data == 401) return m.reply('B\u200cot Di Kick Dari Grup Tersebut❗');
					if (e.data == 410) return m.reply('Url Grup Telah Di Setel Ulang❗');
					if (e.data == 500) return m.reply('Grup Penuh❗');
				}
				await axstore.groupGetInviteInfo(urlny[1]).then(a => {
					addExpired({ url: urlny[1], expired: (teks2?.replace(/[^0-9]/g, '') || 30) + 'd', id: a.id }, sewa)
					m.reply('Sukses Menambahkan Sewa Selama ' + (teks2?.replace(/[^0-9]/g, '') || 30) + ' hari\nOtomatis Keluar Saat Waktu Habis!')
				}).catch(e => m.reply('Gagal Menambahkan Sewa!'))
			} break
		case 'delsewa': {
			  if (!isCreator) return ;
        if (!text) return m.reply(
        `Example:\n${prefix + command} https://chat.whatsapp.com/xxx\n` +
        `${prefix + command} 123456789@g.us`);
        let urlny;
        if (text.includes("chat.whatsapp.com/")) {
          let code = text.match(/chat\.whatsapp\.com\/([0-9A-Za-z]+)/);
          if (!code) return m.reply("Link tidak valid!");
          urlny = code[1];}
          else if (/@g\.us$/.test(text)) {
            urlny = text.trim();}
            else return m.reply("Format tidak valid!");
            let pos = db.sewa.findIndex(v => v.id === urlny || v.url === urlny);
            if (pos === -1) return m.reply("Tidak ditemukan di database sewa!");
            let data = db.sewa[pos];
            m.reply(
        `Sukses menghapus sewa!\n\n` +
        `• Grup : ${data.id}\n` +
        `• Mode : *${data.type.toUpperCase()}*`);
        axstore.groupLeave(data.id).catch(() => {});
        db.sewa.splice(pos, 1);} break
		case 'listsewa': {
			  if (!isCreator) return ;
			  if (db.sewa.length === 0)
			  return m.reply("*Tidak ada grup yang menyewa bot.*");
			  let txt = `*────「 LIST SEWA BOT 」────*\n\n`;
			  for (let s of db.sewa) {
        txt += `➤ *ID*: ${s.id}\n`;
        txt += `➤ *Link*: https://chat.whatsapp.com/${s.url}\n`;
        txt += `➤ *Expired*: ${formatDate(s.expired)}\n\n`;}
        m.reply(txt);} break
    case 'mute': case 'unmute': {
				if (!isCreator) return 
				if (!m.isGroup) return m.reply(mess.group)
				if (command == 'mute') {
					db.groups[m.chat].mute = true
					m.reply('B\u200cot Telah Di Mute Di Grup Ini!')
				} else if (command == 'unmute') {
					db.groups[m.chat].mute = false
					m.reply('Sukses Unmute')
				}
			}	break
//┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
//MENU
//┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
      case 'menu': {
      const menunya =`┃• *Nama Bot* : ${set?.botname || 'AX STORE'}\n┃• *Owner* : ${ownerNumber[0].split('@')[0]}\n┃• *Produk Bot* : ${prefix}list\n┃• *Website* : ${my.website || 'axstore.my.id'}\n┃ketik ${prefix}bel untuk memanggil owner\n\n*LISTMENU*\n${setv} ${prefix}grupmenu - manajemen grup\n${setv} ${prefix}downmenu - downloader menu\n${setv} ${prefix}botmenu - bot utility\n${setv} ${prefix}searchmenu - menu pencarian\n\n*STORE*\n${setv} ${prefix}store - ${mygroupid.gcOfc.includes(m.chat) ? "Store menu" : "Khusus grup official"}`;
                await axstore.sendMessage(m.chat, { text: menunya, contextInfo: { mentionedJid: [m.sender, '0@s.whatsapp.net', ownerNumber[0] + '@s.whatsapp.net'], forwardingScore: 10, isForwarded: true, forwardedNewsletterMessageInfo: { newsletterJid: my.chId, serverMessageId: null, newsletterName: ucapanWaktu }}}, { quoted: m })}; break
      case 'store': {
        m.reply(`*S\u200cTORE MENU*\n${setv} ${prefix}deposit (jumlah)👥\n${setv} ${prefix}bataldp👥\n${setv} ${prefix}saldo👥\n${setv} ${prefix}listproduk👥\n${setv} ${prefix}beli ID|jumlah👥\n${setv} ${prefix}nokoslist👥`)
      } break
      case 'grupmenu': {
        m.reply(`*GRUPMENU*\n${setv} ${prefix}kick (@tag/62xxx)\n${setv} ${prefix}promote (@tag/62xxx)\n${setv} ${prefix}demote (@tag/62xxx)\n${setv} ${prefix}warn (@tag/62xxx)\n${setv} ${prefix}unwarn (@tag/62xxx)\n${setv} ${prefix}setname (nama baru gc)\n${setv} ${prefix}setdesc (desk)\n${setv} ${prefix}setppgc (reply imgnya)\n${setv} ${prefix}delete (reply pesan)\n${setv} ${prefix}urlgrup\n${setv} ${prefix}revoke\n${setv} ${prefix}tagall\n${setv} ${prefix}hidetag\n${setv} ${prefix}totag (reply pesan)\n${setv} ${prefix}listonline\n${setv} ${prefix}grup (khusus admin)\n${setv} ${prefix}acakp (jumlah)`)
      } break
      case 'botmenu': {
        m.reply(`*B\u200cOT MENU*\n${setv} ${prefix}owner👥\n${setv} ${prefix}totalfitur👥\n${setv} ${prefix}runtime\n${setv} ${prefix}ping\n${setv} ${prefix}rvo (reply pesan viewone)\n${setv} ${prefix}inspect (url gc)\n${setv} ${prefix}stiker👥\n${setv} ${prefix}brat👥`)
      } break
      case 'searchmenu': {
        m.reply(`*SEARCH MENU*\n${setv} ${prefix}infohp (query)👥\n${setv} ${prefix}pint (query)👥\n${setv} ${prefix}cekidff (ID)👥\n${setv} ${prefix}cekidml (ID|SERVER)👥\n`)
      } break
      case 'downmenu': {
        m.reply(`*DOWNLOAD MENU*\n${setv} ${prefix}tt (url)👥\n${setv} ${prefix}ig (url)👥\n${setv} ${prefix}spotify (url)👥\n${setv} ${prefix}ytmp3 (url)👥\n`)
      } break
      case 'ownermenu': {
              if (isCreator) m.reply(`*OWNER MENU*\n${setv} ${prefix}bot [set]\n${setv} ${prefix}listgc\n${setv} ${prefix}creategc\n${setv} ${prefix}addsewa\n${setv} ${prefix}delsewa\n${setv} ${prefix}listsewa\n${setv} ${prefix}mute\n\n*STORE MENU*\n${setv} ${prefix}ceksaldo (tag/@62xxxx)\n${setv} ${prefix}addsaldo (tag/@62xxxx)\n${setv} ${prefix}delsaldo (tag/@62xxxx)\n${setv} ${prefix}addproduk Nama|ID|Hrg|Stok\n${setv} ${prefix}delproduk (ID)\n${setv} ${prefix}setstok ID|(-angka/angka)\n${setv} ${prefix}clearantrean\n${setv} ${prefix}cekantrean`
            )}; break
//┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━❂
            default: if ((!isCmd || isCreator) && budy && (budy.toLowerCase() in db.database) && !m.chat.endsWith('broadcast')) await axstore.relayMessage(m.chat, db.database[budy.toLowerCase()], {});
        }
    } catch (e) { console.log(util.format(e))}
};

let file = require.resolve(__filename);
fs.watchFile(file, () => { fs.unwatchFile(file); console.log(chalk.redBright(`Update ${__filename}`)); delete require.cache[file]; require(file); });
