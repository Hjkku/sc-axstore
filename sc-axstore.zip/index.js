const { spawn } = require('child_process');
const path = require('path');

// --- LOGIKA START.JS (MASTER) ---
if (!process.send) { 
    function start() {
        let args = [__filename, ...process.argv.slice(2)];
        let p = spawn(process.argv[0], args, {
            stdio: ['inherit', 'inherit', 'inherit', 'ipc']
        });

        p.on('message', data => {
            if (data === 'reset') {
                console.log(' [SYSTEM] Restarting Bot...');
                p.kill();
                start();
            }
        });

        p.on('exit', code => {
            console.error(' [SYSTEM] Exited with code:', code);
            if (code !== 0) start(); 
        });
    }
    start();
} else {
    // --- LOGIKA INDEX.JS (WORKER/BOT) ---
    runBot();
}

async function runBot() {
    require('./settings');
    const { os, pino, axios, chalk, readline, Boom, NodeCache, qrcode, exec, makeWASocket, useMultiFileAuthState, Browsers, DisconnectReason, makeCacheableSignalKeyStore, fetchLatestWaWebVersion } = {
        os: require('os'), pino: require('pino'), axios: require('axios'), chalk: require('chalk'),
        readline: require('readline'), Boom: require('@hapi/boom').Boom,
        NodeCache: require('node-cache'), qrcode: require('qrcode-terminal'), exec: require('child_process').exec,
        ...(require('baileys'))
    };

    const { dataBase } = require('./src/database'), { app, server, PORT } = require('./src/server'), { assertInstalled, unsafeAgent } = require('./function'), { GroupParticipantsUpdate, MessagesUpsert, Solving } = require('./src/message');

    const print = (l, v) => console.log(`${chalk.green.bold('║')} ${chalk.cyan.bold(l.padEnd(16))}${chalk.yellow.bold(':')} ${v}`);
    const pairingCode = process.argv.includes('--qr') ? false : process.argv.includes('--pairing-code') || global.pairing_code;
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout }), question = (t) => new Promise(r => rl.question(t, r));
    let pairingStarted = false, phoneNumber;

    const database = dataBase(global.tempatDB), 
          userDB = dataBase('users.json'), 
          groupDB = dataBase('groups.json'), 
          produkDB = dataBase('produk.json'),
          storeDB = dataBase(global.tempatStore);

    console.log(chalk.green.bold(`╔═════[ SYSTEM INFO ]═════`));
    print('OS', `${os.platform()} ${os.arch()}`);
    print('Node.js', process.version);
    console.log(chalk.green.bold('╚' + ('═'.repeat(30))));

    global.fetchApi = async (path='/', data={}, options={}) => {
        const base = options.name ? (global.APIs[options.name] || options.name) : global.APIs.naze;
        const apikey = global.APIKeys[base], method = (options.method || 'GET').toUpperCase();
        let url = base + path, headers = { 'user-agent': 'Mozilla/5.0', ...options.headers };
        const res = await axios({ method, url, data: method === 'GET' ? null : { ...data, apikey }, headers, httpsAgent: unsafeAgent, params: method === 'GET' ? { ...data, apikey } : {}, responseType: options.buffer ? 'arraybuffer' : 'json' });
        return options.buffer ? Buffer.from(res.data) : res.data;
    };

    async function startAxstoreBot() {
        const [mainData, userData, groupData, produkData, sLoad] = await Promise.all([
            database.read(), userDB.read(), groupDB.read(), produkDB.read(), storeDB.read()
        ]);

        global.db = { 
            hit:{}, set:{}, cmd:{}, database:{}, premium:[], sewa:[], ...mainData, 
            users: userData || {}, 
            groups: groupData || {},
            produk: produkData || []
        };
        global.store = { contacts:{}, presences:{}, messages:{}, groupMetadata:{}, ...sLoad };
        
        if (!global._dbInterval) {
            global._dbInterval = setInterval(async () => { 
                const { users, groups, produk, ...mainDataOnly } = global.db;
                await Promise.all([
                    database.write(mainDataOnly), 
                    userDB.write(global.db.users), 
                    groupDB.write(global.db.groups), 
                    produkDB.write(global.db.produk),
                    storeDB.write(global.store)
                ]);
            }, 30000);
        }

        const { version } = await fetchLatestWaWebVersion();
        const { state, saveCreds } = await useMultiFileAuthState('axdevs');
        const axstore = makeWASocket({
            version, logger: pino({ level: 'silent' }),
            auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })) },
            browser: Browsers.ubuntu('Chrome'),
            getMessage: async (k) => (global.store.messages?.[k.remoteJid]?.array?.find(m => m.key.id === k.id))?.message || { conversation: 'Axiom Bot' }
        });

        if (pairingCode && !axstore.authState.creds.registered && !phoneNumber) {
            phoneNumber = (global.number_bot || await question('Input WA Number (62xxx): ')).replace(/[^0-9]/g, '');
            exec('rm -rf ./axdevs/*');
        }

        await Solving(axstore, global.store);
        axstore.ev.on('creds.update', saveCreds);

        axstore.ev.on('connection.update', async (u) => {
            const { connection, lastDisconnect, qr } = u;
            if (connection === 'close') {
                let reason = new Boom(lastDisconnect?.error)?.output.statusCode;
                if (reason !== DisconnectReason.loggedOut) startAxstoreBot();
                else { exec('rm -rf ./axdevs/*'); process.exit(1); }
            }
            if (qr && !pairingCode) qrcode.generate(qr, { small: true });
            if (connection === 'open') console.log(chalk.green('✅ Connected: ' + axstore.user.id));
            if ((qr || connection === 'connecting') && pairingCode && phoneNumber && !pairingStarted) {
                pairingStarted = true;
                setTimeout(async () => {
                    console.log(chalk.blue('Pairing Code:'), chalk.green.bold(await axstore.requestPairingCode(phoneNumber)));
                }, 3000);
            }
        });

        // --- EVENT LISTENER (DITAMBAHKAN) ---
        axstore.ev.on('messages.upsert', async (m) => {
            await MessagesUpsert(axstore, m, global.store);
        });

        axstore.ev.on('group-participants.update', async (anu) => {
            await GroupParticipantsUpdate(axstore, anu, global.store);
        });

        return axstore;
    }

    startAxstoreBot();
    server.listen(PORT, () => console.log('Server running on port', PORT));

    const cleanup = async (signal) => {
        const { users, groups, produk, ...mainDataOnly } = global.db;
        await Promise.all([
            database.write(mainDataOnly), 
            userDB.write(global.db.users), 
            groupDB.write(global.db.groups), 
            produkDB.write(global.db.produk),
            storeDB.write(global.store)
        ]);
        process.exit();
    };
    ['SIGINT', 'SIGTERM'].forEach(s => process.once(s, () => cleanup(s)));
}
